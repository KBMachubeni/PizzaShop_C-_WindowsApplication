﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.Net;
using System.Threading;
using HelperLibrary;

namespace Clients
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<Person> person = HelperLibrary.DataHandler.Details();
        BindingSource b = new BindingSource();
        //1. Create a list of Product that receive values from Datahandler Class Method Items.
        //2. Create an object of Binding Source.

   

      

        private void Form1_Load(object sender, EventArgs e)
        {
            b.DataSource = person;
            dgvItems.DataSource = b;

            txtProductName.DataBindings.Add("Text", b, "PizzaDescription");
            txtPrice.DataBindings.Add("Text", b, "PizzaPrice");
            txtPizzaSize.DataBindings.Add("Text", b, "PizzaSize");

            // 1. Binding datagrid view named dgvItems
            // 2. Binding 2 text boxes named txtProductName and txtPrice



        }
        
        private void txtProductName_TextChanged(object sender, EventArgs e)
        {
            //1. Load a correct picture to the PictureBox (picBoxFood)

            foreach (var item in person)
            {
                if (txtProductName.Text == item.PizzaDescription)
                {
                    picBoxFood.Image = Image.FromFile(@"C:\Users\Karabo Machubeni\Documents\B COMP BELGIUM CAMPUS\2ND YEAR\PROGRAMMING 221\PROJECTS\PRG221-Summative Tests [2017-05-26] Memo\Practical\pictures\" + item.PizzaID + ".jpg");
                }
            }
           

        }
        private void numericQuantity_ValueChanged(object sender, EventArgs e)
        {
            //1. Enable btnAddToCart
            btnPlaceOrder.Enabled = true;
           


        }

        int cost = 0;
       // double price = 0.0;
        
        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            //1. Calculate the price of each item
            //2. Add the relevant data to the listbox
            //3. Update the lblTotal Label box as the user add items to the cart must add total
            // 4. Enable btnMakePayment  
            cost = int.Parse(numericQuantity.Value.ToString()) * int.Parse(txtPrice.Text);
            lblTotal.Text = cost.ToString();

            lstCard.Items.Add(txtProductName.Text + " " + txtPrice.Text + " " + numericQuantity.Value + " " + lblTotal.Text.ToString());
            btnMakePayment.Enabled = true;
            cost += int.Parse(lblTotal.Text);
            

        }

        private void btnMakePayment_Click(object sender, EventArgs e)
        {
            //1. Must check if the value in txtPayment is less than the value in lblTotal and display "Insufficient Payment Amount" in Message Box
            //else must calculate the change and Enable btnPrintInvoice but Diable btnAddToCart and btnMakePayment

         
            btnPlaceOrder.Enabled = false;
           
            int payment = int.Parse(txtPayment.Text);
            int total = int.Parse(lblTotal.Text);
            double change ;
            if (total < payment)
            {
                change = payment - total;
                lblChange.Text = change.ToString("C");
                btnPrintInvoice.Enabled = true;
                btnMakePayment.Enabled = false;
            
            }
            else    if(payment.ToString()=="")
        	{
                MessageBox.Show("No Payment Amount", "Warning", MessageBoxButtons.OK);
	        }
            else
            {
                MessageBox.Show("Insufficient Payment Amount", "Warning", MessageBoxButtons.OK);
                btnPrintInvoice.Enabled = false;
                btnMakePayment.Enabled = true;
            
            }
            

        }


       
    private void btnPrintInvoice_Click(object sender, EventArgs e)
        {
            //1. Create a XMLSerialisation
            //2. Serialize all values stored in a ListBox to Invoice.xml file.
            //3. Make btnSendOrders button Vissible

        List<Invoice> invo= new List<Invoice>();
            foreach (var item in lstCard.Items)
            {
                invo.Add(new Invoice(item.ToString()));  
               
            }
            XmlSerializer seriliaze = new XmlSerializer(typeof(List<Invoice>));
            using (TextWriter writer = new StreamWriter(@"kb.xml"))
            {
                seriliaze.Serialize(writer, invo);
            }

      //  Deserialize
            //XmlSerializer des = new XmlSerializer(typeof(List<Invoice>));
            //TextReader reader = new StreamReader("kb.xml");
            //object obj = des.Deserialize(reader);
            //List<Invoice> inv = (List<Invoice>)obj;
            //foreach (var item in inv)
            //{
            //    Console.WriteLine(item.ToString());
            //}


        
        }
            


        private void btnSendOrders_Click(object sender, EventArgs e)
        {
          

            
        }

        private void dgvItems_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
   
}
