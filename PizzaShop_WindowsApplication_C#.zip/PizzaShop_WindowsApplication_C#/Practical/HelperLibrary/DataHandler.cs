﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Windows.Forms;

namespace HelperLibrary
{
    public class DataHandler
    {
        static string connector = ConfigurationManager.ConnectionStrings["Products"].ConnectionString;
        static OleDbConnection connection = new OleDbConnection(connector);

        public static List<Person> Details() 
        {
            List<Person> person = new List<Person>();
            try
            {
                connection.Open();
                if (connection.State == ConnectionState.Open)
                {
                    DataSet ds = new DataSet();
                    OleDbDataAdapter adapt = new OleDbDataAdapter("select * from tblPizza", connection);
                    adapt.Fill(ds);

                    DataTable dt = ds.Tables[0];

                    foreach (DataRow item in dt.Rows)
                    {
                        person.Add(new Person(Convert.ToInt32(item["pizzaID"]), item["pizzaDescription"].ToString(), item["pizzaSize"].ToString(), Convert.ToDouble(item["pizzaPrice"])));
                    }

                }

                else
                {
                    throw new CustomException("Not connected");
                }
            }
            catch (CustomException ex)
            {

                MessageBox.Show(ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally { connection.Close(); }

            return person;
        }
    }
}
