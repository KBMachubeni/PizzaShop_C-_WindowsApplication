﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelperLibrary
{
    [Serializable]
   public class Invoice
    {
        

        private string productName;

        public string ProductName
        {
            get { return productName; }
            set { productName = value; }
        }


        private int priceEach;

        public int PriceEach
        {
            get { return priceEach; }
            set { priceEach = value; }
        }

        private int quantity;

        public int Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }


        private int cost;
        private string p;

        public int Cost
        {
            get { return cost; }
            set { cost = value; }
        }

        public Invoice()
        {

        }

        public Invoice(string p)
        {
            // TODO: Complete member initialization
            this.p = p;
        }


        public override string ToString()
        {
            return string.Format(@"{0} {1} {2} {3}",productName,priceEach,quantity,cost);
        }
    }
}
