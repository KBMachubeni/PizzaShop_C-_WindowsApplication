﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelperLibrary
{
   public class Person
    {


        private int pizzaID;

        public int PizzaID
        {
            get { return pizzaID; }
            set { pizzaID = value; }
        }


        private string pizzaDescription;

        public string PizzaDescription
        {
            get { return pizzaDescription; }
            set { pizzaDescription = value; }
        }


        private string pizzaSize;

        public string PizzaSize
        {
            get { return pizzaSize; }
            set { pizzaSize = value; }
        }


        private double pizzaPrice;

        public double PizzaPrice
        {
            get { return pizzaPrice; }
            set { pizzaPrice = value; }
        }


        public Person(int pizzaID , string pizzaDescription , string pizzaSize , double pizzaPrice )
        {
            this.pizzaID = pizzaID;
            this.pizzaDescription = pizzaDescription;
            this.pizzaSize = pizzaSize;
            this.pizzaPrice = pizzaPrice;
        }

        public override string ToString()
        {
            return string.Format(@"{0} {1} {2} {3}",pizzaID,pizzaDescription,pizzaSize,pizzaPrice);
        }
    }
}
